
def sampleFunction(digit):
	return digit*2